// Entry point
console.log("Codestar app loaded");